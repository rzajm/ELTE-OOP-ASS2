using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using assign_02;

namespace Assignment2Tests
{
    [TestClass]
    public class AreaTests
    {
        [TestMethod]
        public void TestPlainUpdateWeather()
        {
            // Test Plain area with Sunny weather
            IArea area = new Plain("Test1", 'P', 30, 30);
            area = area.UpdateWeather(area.Humidity);
            Assert.AreEqual(27, area.WaterAmount);

            // Test Plain area with Cloudy weather
            area = new Plain("Test2",'P', 25, 45);
            area = area.UpdateWeather(45);
            Assert.AreEqual(24,area.WaterAmount);

            // Test Plain area with Rainy weather
            area = new Plain("Test3",'P', 20, 75);
            area = area.UpdateWeather(75);
            Assert.AreEqual(40, area.WaterAmount);
        }

        [TestMethod]
        public void TestGrasslandUpdateWeather()
        {
            // Test Grassland area with Sunny weather
            IArea area = new Grassland("Test1", 'P', 30, 30);
            area = area.UpdateWeather(30);
            Assert.AreEqual(24, area.WaterAmount);

            // Test Grassland area with Cloudy weather
            area = new Grassland("Test2", 'P', 25, 45);
            area = area.UpdateWeather(45);
            Assert.AreEqual(23, area.WaterAmount);

            // Test Grassland area with Rainy weather
            area = new Grassland("Test3", 'P', 20, 75);
            area = area.UpdateWeather(75); 
            Assert.AreEqual(35, area.WaterAmount);
        }

        [TestMethod]
        public void TestLakesRegionUpdateWeather()
        {
            // Test LakesRegion area with Sunny weather
            IArea area = new LakesRegion("Test1", 'P', 30, 30);
            area = area.UpdateWeather(30); 
            Assert.AreEqual(20, area.WaterAmount);

            // Test LakesRegion area with Cloudy weather
            area = new LakesRegion("Test2", 'P', 25, 45);
            area = area.UpdateWeather(45); 
            Assert.AreEqual(22, area.WaterAmount);

            // Test LakesRegion area with Rainy weather
            area = new LakesRegion("Test3", 'P', 20, 75);
            area = area.UpdateWeather(75); 
            Assert.AreEqual(40, area.WaterAmount);
        }

        [TestMethod]
        public void TestWeatherEnumeration()
        {
            // Test WeatherType enumeration
            WeatherType sunnyWeather = WeatherType.Sunny;
            WeatherType cloudyWeather = WeatherType.Cloudy;
            WeatherType rainyWeather = WeatherType.Rainy;

            Assert.AreEqual(WeatherType.Sunny, sunnyWeather);
            Assert.AreEqual(WeatherType.Cloudy, cloudyWeather);
            Assert.AreEqual(WeatherType.Rainy, rainyWeather);
        }
        [TestMethod]
        public void TestResetHumidity()
        {   //Test Humidity Reset with Plain
            IArea area = new Plain("Test1", 'P', 30, 80);
            area = area.UpdateWeather(area.Humidity);
            Assert.AreEqual(31.5, area.Humidity);

            //Test Humidity Reset with Grassland
            IArea area1= new Grassland("Test2", 'G', 30, 80);
            area1 = area1.UpdateWeather(80);
            Assert.AreEqual(33, area1.Humidity);

            //Test Humidity Reset with LakesRegion

            IArea area2 = new LakesRegion("Test3", 'L', 30, 80);
            area2 = area2.UpdateWeather(80);
            Assert.AreEqual(34.5,area2.Humidity);
        }

        [TestMethod]
        public void TestAreaChange()
        {
            //Testing if the Area type changes to Grassland if its water level is greater than 15

            IArea area = new Plain("Test1", 'P', 30, 80);
            area = area.UpdateWeather(area.Humidity);
            Assert.AreEqual('G', area.Type);

            //Testing if the Area type changes to Lakes Region if its water level is greater than 50

            IArea area1 = new Grassland("Test2", 'G', 80, 80);
            area1 = area1.UpdateWeather(area1.Humidity);
            Assert.AreEqual('L', area1.Type);

            //Testing if the Area type changes to Plain if its water level is less than 16

            IArea area2 = new Grassland("Test2", 'G', 15,30);
            area2 = area2.UpdateWeather(area2.Humidity);
            Assert.AreEqual('P', area2.Type);

            //Testing if the Area type changes to Grassland if its water level is greater than 51

            IArea area3 = new LakesRegion("Test3", 'L', 80, 80);
            area3 = area3.UpdateWeather(area3.Humidity);
            Assert.AreEqual('G',area3.Type);

        }

       
    }
}
