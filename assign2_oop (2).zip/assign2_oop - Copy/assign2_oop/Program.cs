﻿using System;
using TextFile;
using System.Collections.Generic;

namespace assign_02
{
    class Program
    {
        static void Main()
        {
            TextFileReader reader = new("C:\\Users\\User\\source\\repos\\assign2_oop\\assign2_oop\\input.txt");

            reader.ReadLine(out string line);
            int n = int.Parse(line);
            List<IArea> areas = new();
            double humidity = 0;
            for (int i = 0; i <= n; ++i)
            {
                char[] separators = { ' ', '\t' };
                IArea area = null;

                if (i == n)
                {
                    humidity = double.Parse(reader.ReadLine());
                    break;
                }

                if (reader.ReadLine(out line))
                {
                    string[] tokens = line.Split(separators, StringSplitOptions.RemoveEmptyEntries);

                    string name = tokens[0] + " " + tokens[1];
                    char areaType = char.Parse(tokens[2]);
                    int waterAmount = int.Parse(tokens[3]);

                    switch (areaType)
                    {
                        case 'L': area = new LakesRegion(name, areaType, waterAmount, 0); break;
                        case 'G': area = new Grassland(name, areaType, waterAmount, 0); break;
                        case 'P': area = new Plain(name, areaType, waterAmount, 0); break;

                    }
                }

                areas.Add(area);
            }

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine();
                Console.WriteLine($"---------------- Round {i} -----------------");
                Console.WriteLine();
                for (int j = 0; j < n; j++)
                {
                    IArea area = areas[j].UpdateWeather(humidity);
                    humidity = area.Humidity;
                    if (areas[j].WaterAmount > 0) { Console.WriteLine("Owner name: " + areas[j].Name + ", Water Amount: " + areas[j].WaterAmount); }
                }

            }

            int max = int.MinValue;
            string ownerName = "";
            for (int i = 0; i < areas.Count; i++)
            {
                if (areas[i].WaterAmount > max)
                {
                    max = areas[i].WaterAmount;
                    ownerName = areas[i].Name;
                }
            }

            Console.WriteLine();
            Console.WriteLine($"----------------- Result -----------------\n");
            Console.WriteLine("The owner of the area which is storing the greatest amount of water: " + ownerName);
            Console.WriteLine("The amount of water: " + max);



        }
    }
}
