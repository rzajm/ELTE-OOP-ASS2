﻿using TextFile;
using System;
using System.Collections.Generic;
using System.Xml.Linq;
using System.Net.NetworkInformation;
using System.Transactions;

public interface IArea
{
    public IArea UpdateWeather(double humidity);
    public string Name { get; set; }
    public char Type { get; set; }
    public int WaterAmount { get; set; }
    public double Humidity { get; set; }
}

public enum WeatherType
{
    Sunny,
    Cloudy,
    Rainy
}

public class Plain : IArea
{
    public char Type { get; set; }
    public int WaterAmount { get;  set; }
    public string Name { get;  set; }
    public double Humidity { get;  set; }
    public WeatherType weather { get; set; }

    public Plain(string name, char type, int waterAmount, double humidity)
    {
        Name = name;
        Type = type;
        WaterAmount = waterAmount;
        Humidity = humidity;
    }
   
    public IArea UpdateWeather(double humidity)
    {
        WeatherType weather;
        if (humidity > 70)
        {
            weather = WeatherType.Rainy;
            humidity = 30;
        }
        else if (humidity >= 40)
        {
            double rainyChance = (humidity - 40) * 0.033;
            Random random = new Random();
            double randomValue = random.Next(1, 100);
            if (randomValue < rainyChance)
            {
                weather = WeatherType.Rainy;
            }
            else
            {
                weather = WeatherType.Cloudy;
            }
        }
        else
        {
            weather = WeatherType.Sunny;
        }

        switch (weather)
        {
            case WeatherType.Sunny:
                WaterAmount -= 3;
                break;
            case WeatherType.Cloudy:
                WaterAmount -= 1;
                break;
            case WeatherType.Rainy:
                WaterAmount += 20;
                break;
            default:
                throw new ArgumentException("Invalid weather type");
        }

        Humidity = humidity * 1.05;

        if (WaterAmount > 15)
        {
            Grassland newG = new Grassland(Name = this.Name, Type = 'G', WaterAmount = this.WaterAmount, Humidity = this.Humidity);
            return newG;
        }
        
        return this;
    }
}

public class Grassland : IArea
{
    public char Type { get; set; }
    public int WaterAmount { get; set; }
    public string Name { get; set; }
    public double Humidity { get; set; }
    public WeatherType weather{get; set; }

    public Grassland(string name, char type, int waterAmount, double humidity)
    {
        Name = name;
        Type = type;
        WaterAmount = waterAmount;
        Humidity = humidity;
        weather = 0;
    }

    public IArea UpdateWeather(double humidity)
    {
        WeatherType weather;
        if (humidity > 70)
        {
            weather = WeatherType.Rainy;
            humidity = 30;
        }
        else if (humidity >= 40)
        {
            double rainyChance = (humidity - 40) * 0.033;
            Random random = new Random();
            double randomValue = random.NextDouble();
            if (randomValue < rainyChance)
            {
                weather = WeatherType.Rainy;
            }
            else
            {
                weather = WeatherType.Cloudy;
            }
        }
        else
        {
            weather = WeatherType.Sunny;
        }

        switch (weather)
        {
            case WeatherType.Sunny:
                WaterAmount -= 6;
                break;
            case WeatherType.Cloudy:
                WaterAmount -= 2;
                break;
            case WeatherType.Rainy:
                WaterAmount += 15;
                break;
            default:
                throw new ArgumentException("Invalid weather type");
        }
        if (WaterAmount > 50)
        {
            LakesRegion newL = new LakesRegion(Name = this.Name, Type = 'L' , WaterAmount = this.WaterAmount , Humidity = this.Humidity);
            return newL;
        }
        if (WaterAmount < 16)
        {
            Plain newP = new Plain(Name = this.Name,Type= 'P',WaterAmount=this.WaterAmount,Humidity=this.Humidity);
            return newP;
        }
        Humidity = humidity * 1.1;

        return this;
    }   
}

public class LakesRegion : IArea
{
    public char Type { get; set; }
    public int WaterAmount { get; set; }
    public string Name { get; set; }
    public double Humidity { get; set; }
 


    public LakesRegion(string name, char type, int waterAmount, double humidity)
    {
        Name = name;
        Type = type;
        WaterAmount = waterAmount;
        Humidity = humidity;
      
    }

    public IArea UpdateWeather(double humidity)
    {
        WeatherType weather;
        if (humidity > 70)
        {
            weather = WeatherType.Rainy;
            humidity = 30;
        }
        else if (humidity >= 40)
        {
            double rainyChance = (humidity - 40) * 0.033;
            Random random = new Random();
            double randomValue = random.NextDouble();
            if (randomValue < rainyChance)
            {
                weather = WeatherType.Rainy;
            }
            else
            {
                weather = WeatherType.Cloudy;
            }
        }
        else
        {
            weather = WeatherType.Sunny;
        }

        switch (weather)
        {
            case WeatherType.Sunny:
                WaterAmount -= 10;
                break;
            case WeatherType.Cloudy:
                WaterAmount -= 3;
                break;
            case WeatherType.Rainy:
                WaterAmount += 20;
                break;
            default:
                throw new ArgumentException("Invalid weather type");
        }
        if (WaterAmount > 51)
        {
            Grassland newG = new Grassland(Name = this.Name, Type = 'G', WaterAmount = this.WaterAmount, Humidity = this.Humidity);
            return newG;
        }

        Humidity = humidity * 1.15;

        return this;
    }
}

